package com.Booking;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BId")
	private String BId;
	@Column(name="BType")
	private String BType;
	@Column(name="BDate")
	private String BDate;
	
	public String getBId() {
		return BId;
	}
	public void setBId(String id) {
		BId = id;
	}
	public String getBType() {
		return BType;
	}
	public void setBType(String bType) {
		BType = bType;
	}
	public String getBDate() {
		return BDate;
	}
	public void setBDate(String bDate) {
		BDate = bDate;
	}
	

}
