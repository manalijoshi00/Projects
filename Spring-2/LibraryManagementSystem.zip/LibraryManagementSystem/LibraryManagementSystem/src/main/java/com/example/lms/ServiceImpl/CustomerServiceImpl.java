package com.example.lms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.entity.Customer;
import com.example.lms.repository.CustomerRepository;
import com.example.lms.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepository crepo;

	@Override
	public Customer saveC(Customer customer){
		return crepo.save(customer);
	}

	@Override
	public Customer getCid(long id) {
		return crepo.findById(id).get();
	}

	@Override
	public List<Customer> getC() {
		return crepo.findAll();
	}

	@Override
	public Customer updateCid(Customer customer, long id) {
		
		Customer cs = crepo.findById(id).get();
		
		cs.setEmail(customer.getEmail());
		
		crepo.save(cs);
		
		return cs;
	}

	@Override
	public void deleteCid(long id) {
		
		crepo.findById(id).get();
		crepo.deleteById(id);
		
	}
	
	@Override
	public List<Customer> getCEmail(String email){
		
		return crepo.getCEmail(email);
	}


}
