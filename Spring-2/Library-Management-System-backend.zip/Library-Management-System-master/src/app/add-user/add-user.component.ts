import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent {

  user = new User();

  constructor(private _route: Router, private _service: UserServiceService) { }

  ngOnInit(): void {
    
  }

  adduserformLogin() { 
    this._service.adduserToRemote(this.user).subscribe
    (
      data =>
              {
                console.log("data added successfully");
                this._route.navigate(['userlist']);
              },
      error => console.log("error") 
    )
  }

  gotolist() {
    console.log('go back');
    this._route.navigate(['userlist']);
  }


}
