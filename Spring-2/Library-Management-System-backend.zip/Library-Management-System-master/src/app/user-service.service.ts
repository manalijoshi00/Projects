import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { User } from './user';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private _http: HttpClient) { }

  userListFromRemote(): Observable<any>{
    return this._http.get<any>("http://localhost:8080/users");
  }

  adduserToRemote(user: User):Observable<any>{
    return this._http.post<any>("http://localhost:8080/addUser",user);
  }
}
