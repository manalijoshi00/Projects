import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddBookComponent } from './add-book/add-book.component';
import { AddUserComponent } from './add-user/add-user.component';
import { BookListComponent } from './book-list/book-list.component';
import { EditBookComponent } from './edit-book/edit-book.component';
import { UserListComponent } from './user-list/user-list.component';
import { ViewBookComponent } from './view-book/view-book.component';

const routes: Routes = [
  {path: '', component: BookListComponent},
  {path: 'addbook', component: AddBookComponent},
  {path: 'editbook/:id', component: EditBookComponent},
  {path: 'editbook', component: EditBookComponent},
  {path: 'viewbook', component: ViewBookComponent},
  {path: 'viewbook/:id', component: ViewBookComponent},
  {path: 'booklist', component: BookListComponent},
  {path: 'userlist', component: UserListComponent},
  {path: 'adduser', component: AddUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
