package com.example.lms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.entity.Book;
import com.example.lms.service.BookService;

@RestController

public class BookController {
	
	@Autowired
	private BookService bookservice;
	
	@PostMapping("/saveBook")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<Book> saveBook(@Valid @RequestBody Book book){
		return new ResponseEntity<Book>(bookservice.saveB(book), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getAllBooks")
	public List<Book> getBook(){
		return bookservice.getB();
	}
	
	@GetMapping("/getBookId/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<Book> getBookId(@PathVariable long id){
		return new ResponseEntity<Book>(bookservice.getBid(id), HttpStatus.OK);
	}
	
	@PutMapping("/updateBookId/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<Book> updateBookId(@PathVariable long id, @RequestBody Book book){
		return new ResponseEntity<Book>(bookservice.updateBid(book, id), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteBookId/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<String> deleteBookId(@PathVariable long id){
		bookservice.deleteBid(id);
		return new ResponseEntity<String>("deleted successfully", HttpStatus.OK);
	}
	
	@GetMapping("/getBookName/{name}")
	public List<Book> getBookName(@PathVariable String name){
		return bookservice.getBName(name);
	}

}
