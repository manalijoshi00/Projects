import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Book } from '../book';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {
  book = new Book();

  constructor(private _route:Router, private _service: ServiceService) { }

  ngOnInit(): void {
    
  }

  addbookformsubmit() { 
    this._service.addbookToRemote(this.book).subscribe
    (
      data =>
              {
                console.log("data added successfully");
                this._route.navigate(['booklist']);
              },
      error => console.log("error") 
    )
  }

  gotolist() {
    console.log('go back');
    this._route.navigate(['booklist']);
  }

}
