package com.Booking;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class BookingController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String Id = JOptionPane.showInputDialog(jp, "Enter your ID:");
		     String BType = JOptionPane.showInputDialog(jp, "Enter your BTYP:");
		     String BDate = JOptionPane.showInputDialog(jp, "Enter your BDate:");
		     
		     Booking b = new Booking();
		     b.setBId(Id);
		     b.setBType(BType);
		     b.setBDate(BDate);
		     em.persist(b);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Booking b2 = em.find(Booking.class, 1);
		
		String BType= b2.getBType();
		et.commit();
		return BType;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Booking b2 = em.find(Booking.class, 1);
		b2.setBType("BType"); 
		System.out.println("Updated.."+b2.getBType());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Booking b2 = em.find(Booking.class, 4);
		if(b2!=null)
			em.remove(b2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }

}
