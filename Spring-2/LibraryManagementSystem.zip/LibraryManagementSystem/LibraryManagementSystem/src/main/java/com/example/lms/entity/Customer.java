package com.example.lms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;


import lombok.Data;

@Data
@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "firstname cannot be blank")
	private String firstname;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "lastname cannot be blank")
	private String lastname;
	
	@Column(length = 100, unique = true,  nullable = false)
	@NotBlank(message = "enter the email")
	private String email;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "enter the phonenumber")
	private String phonenumber;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "enter the city")
	private String city;
	

}
