package com.example.lms.service;

import java.util.List;

import com.example.lms.entity.Book;

public interface BookService {
	
	//saving all book details from db table 
	Book saveB(Book book);
	
	//feching book details from db table based on id
	Book getBid(long id);
	
	//feching book details from db table 
	List<Book> getB();
	
	//modifying book details from db table based on id
	Book updateBid(Book book, long id);
	
	//removing book details from db table based on id
	void deleteBid(long id);

	List<Book> getBName(String name);
	
	
	

}
