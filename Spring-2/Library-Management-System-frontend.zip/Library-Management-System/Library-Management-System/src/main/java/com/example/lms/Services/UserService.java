package com.example.lms.Services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.Repository.UserRepository;
import com.example.lms.entity.User;

@Service
public class UserService {
	
	@Autowired
	private UserRepository urepo;

	public List<User> findAll() {

		return urepo.findAll();
	}

	public User save(User user) {
		
		return urepo.save(user);
	}

}
