import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ServiceService } from '../service.service';
import { Book } from '../book';
@Component({
  selector: 'app-edit-book',
  templateUrl: './edit-book.component.html',
  styleUrls: ['./edit-book.component.css']
})
export class EditBookComponent implements OnInit{

  book = new Book();

  constructor(private _route: Router, private _service: ServiceService, private _activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id = parseInt(this._activatedRoute.snapshot.paramMap.get('id') || '{}');
    this._service.fetchBookByIdFromRemote(id).subscribe(
      data => {
        console.log("data recieved");
        this.book = data;
      },
      error => console.log("exception occured")
    )
  }

  updateBookformsubmit() { 
    this._service.addbookToRemote(this.book).subscribe
    (
      data =>
              {
                console.log("data added successfully");
                this._route.navigate(['booklist']);
              },
      error => console.log("error") 
    )
  }

  gotolist() {
    console.log('go back');
    this._route.navigate(['booklist']);
  }

}
