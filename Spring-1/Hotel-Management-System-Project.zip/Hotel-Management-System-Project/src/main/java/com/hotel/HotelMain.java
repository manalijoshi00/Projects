package com.hotel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.Booking.Booking;
import com.Booking.BookingController;

public class HotelMain {

	public static void main(String[] args) {
		
		String hotelName="";
		HotelController hc=new HotelController();
		Hotel hotel=new Hotel();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(hc.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					hotelName=hc.ViewData();
					System.out.println("HOTEL NAME" + hotelName);
					break;
				}
				case 3: {
					
					if(hc.updateData())
					 System.out.println("Updated Successfully:" +hotelName);		
					 break;
				}
				case 4: {
					if(hc.deleteData())
					System.out.println("Removed Successfully:" +hotelName);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}
			


	}

}
