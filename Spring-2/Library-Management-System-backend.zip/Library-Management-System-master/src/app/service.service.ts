import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Book } from './book';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  constructor(private _http:HttpClient) { }

  bookListFromRemote():Observable<any>{
    return this._http.get<any>("http://localhost:8080/books");
  }

  addbookToRemote(book: Book):Observable<any>{
    return this._http.post<any>("http://localhost:8080/addBook",book);
  }

  fetchBookByIdFromRemote(id: number):Observable<any>{
    return this._http.get<any>("http://localhost:8080/getbookbyid/" +id);
  }

  deleteBookByIdFromRemote(id: number):Observable<any>{
    return this._http.delete<any>("http://localhost:8080/deletebookbyid/" +id);
  }
}
