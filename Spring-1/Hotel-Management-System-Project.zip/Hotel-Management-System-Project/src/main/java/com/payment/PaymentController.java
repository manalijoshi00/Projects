package com.payment;

import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.Booking.Booking;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class PaymentController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String paymentDate = JOptionPane.showInputDialog(jp, "Enter your paymentDate:");
		     String paymentAmount = JOptionPane.showInputDialog(jp, "Enter your paymentAmount:");
		     
		     Payment p = new Payment();
		     p.setPaymentDate(paymentDate);
		     p.setPaymentAmount(paymentAmount);
		     em.persist(p);// Insert Query
		     
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		 Payment p2 = em.find( Payment.class, 1);
		
		String paymentAmount= p2.getPaymentAmount();
		et.commit();
		return paymentAmount;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Payment p2 = em.find(Payment.class, 1);
		p2.setPaymentAmount("paymentAmount"); 
		System.out.println("Updated.."+p2.getPaymentAmount());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Payment p2= em.find(Payment.class, 4);
		if(p2!=null)
			em.remove(p2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }


}
