package com.Billing;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class BillingLogic {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String RoomCharge = JOptionPane.showInputDialog(jp, "Enter your RoomCharge:");
		     String MiscCharges = JOptionPane.showInputDialog(jp, "Enter your MiscCharges:");
		     String CreditCardNo = JOptionPane.showInputDialog(jp, "Enter your CreditCardNo:");
		     
		     Billing b = new Billing();
		     b.setRoomCharge(RoomCharge);
		     b.setMiscCharges(MiscCharges);
		     b.setCreditCardNo(CreditCardNo);
		     b.setPaymentDate(java.sql.Date.valueOf("2022-10-23"));
		     
		     em.persist(b);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public int ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Billing b2 = em.find(Billing.class,1);
		
		String RoomCharge= b2.getRoomCharge();
		et.commit();
		return 0;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Billing b2 = em.find(Billing.class, 1);
		b2.getMiscCharges(); 
		System.out.println("Updated.."+b2.getMiscCharges());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Billing b2 = em.find(Billing.class, 5);
		if(b2!=null)
			em.remove(b2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }





}
