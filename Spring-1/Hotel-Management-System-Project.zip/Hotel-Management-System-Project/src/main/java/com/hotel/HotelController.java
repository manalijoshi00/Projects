package com.hotel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.Booking.Booking;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class HotelController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String hotelId=JOptionPane.showInputDialog(jp, "Enter your hotelId:");
		     String hotelName = JOptionPane.showInputDialog(jp, "Enter your hotelName:");
		     String hotelType = JOptionPane.showInputDialog(jp, "Enter your hotelType:");
		     String hotelRent = JOptionPane.showInputDialog(jp, "Enter your hotelRent:");
		     String hotelAddress = JOptionPane.showInputDialog(jp, "Enter your hotelAddress:");
		     
		     Hotel h = new Hotel();
		     h.setHotelName(hotelName);
		     h.setHotelType(hotelType);
		     h.setHotelRent(hotelRent);
		     h.setHotelAddress(hotelAddress);
		     em.persist(h);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotel h2 = em.find(Hotel.class,1);
		
		String hotelName= h2.getHotelName();
		et.commit();
		return hotelName;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotel h2 = em.find(Hotel.class, 1);
		h2.setHotelType("HotelType"); 
		System.out.println("Updated.."+h2.getHotelType());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotel h2 = em.find(Hotel.class, 4);
		if(h2!=null)
			em.remove(h2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }


}
