export class Book {
    id: number;
    bookname: String;
    genre: String;
    author: String;
    published: number;

    constructor(id?: number,bookname?: String,genre?: String,author?: String,published?: number) {
        this.id = id || 0;
        this.bookname = bookname || '';
        this.genre = genre || '';
        this.author = author || '';
        this.published = published || 0;
    }
}
