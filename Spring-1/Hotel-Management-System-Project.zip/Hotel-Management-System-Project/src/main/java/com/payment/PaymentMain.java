package com.payment;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class PaymentMain {

	public static void main(String[] args) {
		
		String paymentAmount="";
		PaymentController pc=new PaymentController();
		Payment payment=new Payment();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(pc.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					paymentAmount=pc.ViewData();
					System.out.println("PAYMENT AMOUNT" + paymentAmount);
					break;
				}
				case 3: {
					
					if(pc.updateData())
					 System.out.println("Updated Successfully:" +paymentAmount);		
					 break;
				}
				case 4: {
					if(pc.deleteData())
					System.out.println("Removed Successfully:" +paymentAmount);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}
			
	}

}
