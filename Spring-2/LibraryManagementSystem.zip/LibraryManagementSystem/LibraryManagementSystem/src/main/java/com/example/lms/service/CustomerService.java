package com.example.lms.service;

import java.util.List;

import com.example.lms.entity.Customer;

public interface CustomerService {
	
	//saving all customer details from db table 
		Customer saveC(Customer customer);
		
		//feching customer details from db table based on id
		Customer getCid(long id);
		
		//feching customer details from db table 
		List<Customer> getC();
		
		//modifying customer details from db table based on id
		Customer updateCid(Customer customer, long id);
		
		//removing customer details from db table based on id
		void deleteCid(long id);

		List<Customer> getCEmail(String email);
		


		

}
