import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { Book } from '../book';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-list',
  templateUrl: './book-list.component.html',
  styleUrls: ['./book-list.component.css']
})
export class BookListComponent implements OnInit{

  _booklist: Book[] = [];
  constructor(private _service: ServiceService,private _route: Router) { }

  ngOnInit(): void {
    this._service.bookListFromRemote().subscribe(
        data => {
          console.log("response recieved");
          this._booklist=data;
        },
        error => console.log("exception occured") 
    ) 
  } 

goToAddBook () {
  this._route.navigate(['/addbook']);
}  

goToEditBook (id : number) {
  console.log("id" +id);
  this._route.navigate(['/editbook',id]);
}

goToViewBook (id : number) {
  console.log("id" +id);
  this._route.navigate(['/viewbook',id]);
}

deleteBook(id: number) {
  this._service.deleteBookByIdFromRemote(id).subscribe(
    data => {
      console.debug("deleted successfully");
      this._route.navigate(['/booklist']);
    },
    error => console.log("Exception occured")
  )
}

}
