package com.example.lms.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.Services.BookService;
import com.example.lms.entity.Book;

@RestController

public class BookController {
	
	@Autowired
	private BookService service;
	
	@GetMapping("/books")
	@CrossOrigin(origins = "http://localhost:4200")
	public List<Book> getAllBooks() {
		return service.findAll();
	}
	
	@PostMapping("/addBook")
	@CrossOrigin(origins = "http://localhost:4200")
	public Book saveBook(@RequestBody Book book){
		return service.save(book);
	}
	
	@GetMapping("/getbookbyid/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public Book fetchBookById(@PathVariable long id) {
		return service.fetchBookById(id).get();
	}
	
	@DeleteMapping("/deletebookbyid/{id}")
	@CrossOrigin(origins = "http://localhost:4200")
	public String DeleteBookById(@PathVariable long id) {
		return service.deleteBookById(id);
	}
	
}
