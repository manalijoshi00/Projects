package com.Hotel;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Hotels")
public class Hotels {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="HotelId")
	private int HotelId;
	@Column(name="HotelName")
	private String HotelName;
	@Column(name="City")
	private String City;
	@Column(name="State")
	private String State;
	@Column(name="HotelType")
	private String HotelType;
	@Column(name="HotelRent")
	private String HotelRent;
	@Column(name="Zipcode")
	private String Zipcode;
	
	public int getHotelId() {
		return HotelId;
	}
	public void setHotelId(int hotelId) {
		HotelId = hotelId;
	}
	public String getHotelName() {
		return HotelName;
	}
	public void setHotelName(String hotelName) {
		HotelName = hotelName;
	}
	public String getCity() {
		return City;
	}
	public void setCity(String city) {
		City = city;
	}
	public String getState() {
		return State;
	}
	public void setState(String state) {
		State = state;
	}
	public String getHotelType() {
		return HotelType;
	}
	public void setHotelType(String hotelType) {
		HotelType = hotelType;
	}
	public String getHotelRent() {
		return HotelRent;
	}
	public void setHotelRent(String hotelRent) {
		HotelRent = hotelRent;
	}
	public String getZipcode() {
		return Zipcode;
	}
	public void setZipcode(String zipcode) {
		Zipcode = zipcode;
	}
	

}
