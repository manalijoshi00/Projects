package com.example.lms.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.entity.User;
import com.example.lms.repository.UserRepository;
import com.example.lms.service.UserService;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	UserRepository urepo;
	
	@Override
	
	public  User loginU(String userName, String password) {
		User user = urepo.findByUserNameAndPassword(userName, password);
		return user;
		
	}
	

}
