package com.example.lms.service;

import com.example.lms.entity.User;

public interface UserService {
	
	public User loginU(String userName, String password);

}
