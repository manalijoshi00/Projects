package com.example.lms.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.example.lms.entity.Book;

public interface BookRepository extends JpaRepository<Book, Long> {
	
	//custom query
	
	@Query("select b from Book b where b.name = ?1")
	List<Book> getBName(String name);

}
