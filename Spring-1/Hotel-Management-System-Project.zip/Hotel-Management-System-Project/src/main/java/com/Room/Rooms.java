package com.Room;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Rooms")
public class Rooms {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RoomId")
	private int RoomId;
	@Column(name="RoomNumber")
	private String RoomNumber;
	@Column(name="RoomType")
	private String RoomType;
	@Column(name="NumberOfBeds")
	private String NumberOfBeds;
	
	public int getRoomId() {
		return RoomId;
	}
	public void setRoomId(int roomId) {
		RoomId = roomId;
	}
	public String getRoomNumber() {
		return RoomNumber;
	}
	public void setRoomNumber(String roomNumber) {
		RoomNumber = roomNumber;
	}
	public String getRoomType() {
		return RoomType;
	}
	public void setRoomType(String roomType) {
		RoomType = roomType;
	}
	public String getNumberOfBeds() {
		return NumberOfBeds;
	}
	public void setNumberOfBeds(String numberOfBeds) {
		NumberOfBeds = numberOfBeds;
	}
	


}
