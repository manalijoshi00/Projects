package com.example.lms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.lms.entity.Customer;
import com.example.lms.service.CustomerService;

@RestController
@RequestMapping()
public class CustomerController {
	
	@Autowired
	private CustomerService customerservice;
	
	@PostMapping("/saveCustomer")
	public ResponseEntity<Customer> saveCustomer(@Valid @RequestBody Customer customer){
		return new ResponseEntity<Customer>(customerservice.saveC(customer), HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getAllCustomer")
	public List<Customer> getCustomer(){
		return customerservice.getC();
	}
	
	@GetMapping("/getCustomerId/{id}")
	public ResponseEntity<Customer> getCustomerId(@PathVariable long id){
		return new ResponseEntity<Customer>(customerservice.getCid(id), HttpStatus.OK);
	}
	
	@PutMapping("/updateCustomerId/{id}")
	public ResponseEntity<Customer> updateCustomerId(@PathVariable long id, @RequestBody Customer customer){
		return new ResponseEntity<Customer>(customerservice.updateCid(customer, id), HttpStatus.OK);
	}
	
	@DeleteMapping("/deleteCustomerId/{id}")
	public ResponseEntity<String> deleteCustomerId(@PathVariable long id){
		customerservice.deleteCid(id);
		return new ResponseEntity<String>("deleted successfully", HttpStatus.OK);
	}
	
	@GetMapping("/getCustomerEmail/{email}")
	public List<Customer> getCustomerEmail(@PathVariable String email){
		return customerservice.getCEmail(email);
	}

}
