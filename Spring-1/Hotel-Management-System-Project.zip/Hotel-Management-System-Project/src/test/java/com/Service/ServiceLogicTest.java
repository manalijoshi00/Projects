package com.Service;

import static org.junit.Assert.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.Test;

public class ServiceLogicTest {

	@Test
	public void testAddData() {
		ServiceLogic s = new ServiceLogic();
		assertTrue(s.addData());
	}

}
