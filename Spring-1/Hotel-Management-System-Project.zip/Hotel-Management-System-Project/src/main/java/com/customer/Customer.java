package com.customer;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CId")
	private int CId;
	@Column(name="CName")
	private String CName;
	@Column(name="CAge")
	private String CAge;
	@Column(name="Gender")
	private String Gender;
	@Column(name="CMobile")
	private long CMobile;
	@Column(name="CEmail")
	private String CEmail;
	@Column(name="CAddress")
	private String CAddress;
	
	public int getCId() {
		return CId;
	}
	public void setCId(int cId) {
		CId = cId;
	}
	public String getCName() {
		return CName;
	}
	public void setCName(String cName) {
		CName = cName;
	}
	public String getCAge() {
		return CAge;
	}
	public void setCAge(String string) {
		CAge = string;
	}
	public String getGender() {
		return Gender;
	}
	public void setGender(String gender) {
		Gender = gender;
	}
	public long getCMobile() {
		return CMobile;
	}
	public void setCMobile(long cMobile) {
		CMobile = cMobile;
	}
	public String getCEmail() {
		return CEmail;
	}
	public void setCEmail(String cEmail) {
		CEmail = cEmail;
	}
	public String getCAddress() {
		return CAddress;
	}
	public void setCAddress(String cAddress) {
		CAddress = cAddress;
	}
	
}
