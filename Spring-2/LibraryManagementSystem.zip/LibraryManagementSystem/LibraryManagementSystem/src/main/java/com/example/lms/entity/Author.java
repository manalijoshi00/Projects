package com.example.lms.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;

@Data
@Entity
public class Author {
	
	@Id
	private Long aid;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "authorname cannot be blank")
	private String name;
	
	@Column(length = 100, nullable = false)
	@NotBlank(message = "surname cannot be blank")
	private String surname;
	
	@ManyToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name="bookId", referencedColumnName = "id")
	@JsonBackReference
	private Book book;

}
