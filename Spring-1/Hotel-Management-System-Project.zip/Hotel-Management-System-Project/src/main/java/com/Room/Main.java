package com.Room;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		String RoomType ="";
		RoomLogic rl=new RoomLogic();
		Rooms room=new Rooms();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(rl.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					RoomType=rl.ViewData();
					System.out.println("ROOM TYPE" + RoomType);
					break;
				}
				case 3: {
					
					if(rl.updateData())
					 System.out.println("Updated Successfully:" +RoomType);		
					 break;
				}
				case 4: {
					if(rl.deleteData())
					System.out.println("Removed Successfully:" +RoomType);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}


	}

}
