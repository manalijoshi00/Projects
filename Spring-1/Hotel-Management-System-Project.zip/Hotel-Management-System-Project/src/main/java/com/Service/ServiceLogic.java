package com.Service;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class ServiceLogic {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String ServiceName = JOptionPane.showInputDialog(jp, "Enter your ServiceName:");
		     String ServiceType = JOptionPane.showInputDialog(jp, "Enter your ServiceType:");
		     
		     Services s = new Services();
		     s.setServiceName(ServiceName);
		     s.setServiceType(ServiceType);
		     em.persist(s);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		 Services s2 = em.find(Services.class, 1);
		
		String ServiceName= s2.getServiceName();
		et.commit();
		return ServiceName;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Services s2 = em.find(Services.class, 1);
		s2.setServiceType("ServiceType");// UPDATE QUERY
		System.out.println("Updated.."+s2.getServiceType());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Services s2= em.find(Services.class, 6);
		if(s2!=null)
			em.remove(s2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }


}
