package com.room;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class RoomController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String roomId = JOptionPane.showInputDialog(jp, "Enter your roomId:");
		     String roomNumber = JOptionPane.showInputDialog(jp, "Enter your roomNumber:");
		     String roomCategory = JOptionPane.showInputDialog(jp, "Enter your roomCategory:");
		     String roomType = JOptionPane.showInputDialog(jp, "Enter your roomType:");
		     
		     Room r = new Room();
		     r.setRoomNumber(roomNumber);
		     r.setRoomCategory(roomCategory);
		     r.setRoomType(roomType);
		     em.persist(r);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Room r2 = em.find(Room.class, 1);
		
		String roomNumber= r2.getRoomNumber();
		et.commit();
		return roomNumber;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Room r2 = em.find(Room.class, 1);
		r2.setRoomNumber("roomNumber"); 
		System.out.println("Updated.."+r2.getRoomNumber());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Room r2 = em.find(Room.class, 4);
		if(r2!=null)
			em.remove(r2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }


}
