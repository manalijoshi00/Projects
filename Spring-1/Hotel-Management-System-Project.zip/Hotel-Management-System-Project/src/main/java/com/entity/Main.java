package com.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		
		EntityManager entityM;
		EntityManagerFactory factory;
		factory = Persistence.createEntityManagerFactory("HotelManagementUnit");
		entityM = factory.createEntityManager();
		
		entityM.getTransaction().begin();
		
		Reservation r = new Reservation();
		r.setCheckInDate(java.sql.Date.valueOf("2022-10-15"));
		r.setCheckOutDate(java.sql.Date.valueOf("2022-10-23"));
		r.setStatus("CheckOut");
		r.setNumberOfGuest(4);
		r.setReservationDate(java.sql.Date.valueOf("2022-10-10"));
		
		Customer c1 = new Customer();
		c1.setFirstName("Sonali");
		c1.setLastName("Jadhav");
		c1.setPhoneNumber(982567147);
		c1.setCity("Chiplun");
		c1.setState("Maharashtra");
		c1.setZipcode(415605);
		c1.setReservation(r);
		
		Customer c2 = new Customer();
		c2.setFirstName("Siddhita");
		c2.setLastName("More");
		c2.setPhoneNumber(943701627);
		c2.setCity("Pune");
		c2.setState("Maharashtra");
		c2.setZipcode(411001);
		c2.setReservation(r);
		
		Customer c3 = new Customer();
		c3.setFirstName("Swarupa");
		c3.setLastName("patil");
		c3.setPhoneNumber(936508256);
		c3.setCity("Mumbai");
		c3.setState("Maharashtra");
		c3.setZipcode(400103);
		c3.setReservation(r);
		
		Customer c4 = new Customer();
		c4.setFirstName("Nilam");
		c4.setLastName("Khedekar");
		c4.setPhoneNumber(637901248);
		c4.setCity("Chiplun");
		c4.setState("Maharashtra");
		c4.setZipcode(415605);
		c4.setReservation(r);
		
		Set<Customer> s = new HashSet<Customer>();
        s.add(c1);
        s.add(c2);
        s.add(c3);
        s.add(c4);
        
		r.setCustomer(s);
		entityM.persist(r);
		entityM.getTransaction().commit();
		
		entityM.getTransaction().begin();
		Reservation re = entityM.find(Reservation.class,1);
		System.out.println("Reservation number is " + re.getRNumber());
        System.out.println("Check in Date is " + re.getCheckInDate());
        System.out.println("Check out Date is " + re.getCheckOutDate());
        System.out.println("Reservation Status is " + re.getStatus());
        System.out.println("Number of Guest is " + re.getNumberOfGuest());
        System.out.println("Reservation Date is " + re.getReservationDate());
		
        Set<Customer> c = re.getCustomer();
        
        for (Customer customer : c) {
                System.out.println("customer id is " + customer.getCustomerId());
                System.out.println("customer first name is " + customer.getFirstName());
                System.out.println("customer last name is " + customer.getLastName());
                System.out.println("customer phone number is " + customer.getPhoneNumber());
                System.out.println("City is " + customer.getCity());
                System.out.println("State is " + customer.getState());
                System.out.println("Zipcode is " + customer.getZipcode());
        }
        
        Customer customer = entityM.find(Customer.class,2);
        System.out.println("customer id is " + customer.getCustomerId());
        System.out.println("customer first name is " + customer.getFirstName());
        System.out.println("customer last name is " + customer.getLastName());
        System.out.println("customer phone number is " + customer.getPhoneNumber());
        System.out.println("City is " + customer.getCity());
        System.out.println("State is " + customer.getState());
        System.out.println("Zipcode is " + customer.getZipcode());
        
        System.out.println("customer Reservation is " + customer.getReservation().getRNumber());
        System.out.println("customer Reservation is " + customer.getReservation().getCheckInDate());
        System.out.println("customer Reservation is " + customer.getReservation().getCheckOutDate());
        System.out.println("customer Reservation is " + customer.getReservation().getStatus());
        System.out.println("customer Reservation is " + customer.getReservation().getNumberOfGuest());
        System.out.println("customer Reservation is " + customer.getReservation().getReservationDate());
        
        
        entityM.getTransaction().commit();
		entityM.close();
		factory.close();	

	}

}
