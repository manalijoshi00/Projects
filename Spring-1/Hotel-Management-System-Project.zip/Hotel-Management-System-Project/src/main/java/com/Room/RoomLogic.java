package com.Room;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class RoomLogic {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String RoomNumber = JOptionPane.showInputDialog(jp, "Enter your RoomNumber:");
		     String RoomType = JOptionPane.showInputDialog(jp, "Enter your RoomType:");
		     String NumberOfBeds = JOptionPane.showInputDialog(jp, "Enter your NumberOfBeds:");
		    
		     Rooms r = new Rooms();
		     r.setRoomNumber(RoomNumber);
		     r.setRoomType(RoomType);
		     r.setNumberOfBeds(NumberOfBeds);
		     
		     em.persist(r);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Rooms r2 = em.find(Rooms.class,1);
		
		String RoomType= r2.getRoomType();
		et.commit();
		return RoomType;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Rooms r2 = em.find(Rooms.class, 1);
		r2.setRoomType("RoomType"); 
		System.out.println("Updated.."+r2.getRoomType());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Rooms r2 = em.find(Rooms.class, 6);
		if(r2!=null)
			em.remove(r2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }




}
