package com.payment;

import java.util.List;

import com.customer.Customer;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Payment")
public class Payment {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="paymentId")
	private String paymentId;
	@Column(name="paymentCId")
	private String paymentCId;
	@Column(name="paymentDate")
	private String paymentDate;
	@Column(name="paymentAmount")
	private String paymentAmount;
	
	private int CId;
	@OneToMany(cascade=CascadeType.ALL)
    @JoinColumn(name="CId")
	private List<Customer> customerTables;
	
	public String getPaymentId() {
		return paymentId;
	}
	public void setPaymentId(String paymentId2) {
		this.paymentId = paymentId2;
	}
	public String getPaymentCId() {
		return paymentCId;
	}
	public void setPaymentCId(String paymentCId2) {
		this.paymentCId = paymentCId2;
	}
	public String getPaymentDate() {
		return paymentDate;
	}
	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}
	public String getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(String paymentAmount2) {
		this.paymentAmount = paymentAmount2;
	}
	
	public List<Customer> getCustomerTables() {
		return customerTables;
	}
	public void setCustomerTables(List<Customer> customerTables) {
		this.customerTables = customerTables;
	}

}
