package com.Billing;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="Billing")
public class Billing {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BillingId")
	private int BillingId;
	@Column(name="RoomCharge")
	private String RoomCharge;
	@Column(name="MiscCharges")
	private String MiscCharges;
	@Column(name="CreditCardNo")
	private String CreditCardNo;
	@Column(name="PaymentDate")
	private Date PaymentDate;

	public int getBillingId() {
		return BillingId;
	}
	public void setBillingId(int billingId) {
		BillingId = billingId;
	}
	public String getRoomCharge() {
		return RoomCharge;
	}
	public void setRoomCharge(String roomCharge) {
		RoomCharge = roomCharge;
	}
	public String getMiscCharges() {
		return MiscCharges;
	}
	public void setMiscCharges(String miscCharges) {
		MiscCharges = miscCharges;
	}
	public String getCreditCardNo() {
		return CreditCardNo;
	}
	public void setCreditCardNo(String creditCardNo) {
		CreditCardNo = creditCardNo;
	}
	public Date getPaymentDate() {
		return PaymentDate;
	}
	public void setPaymentDate(Date paymentDate) {
		PaymentDate = paymentDate;
	}
	

}
