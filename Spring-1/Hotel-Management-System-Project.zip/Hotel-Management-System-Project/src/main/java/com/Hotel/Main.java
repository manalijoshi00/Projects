package com.Hotel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		String HotelName = "";
		HotelLogic hl=new HotelLogic();
		Hotels hotel=new Hotels();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(hl.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					HotelName=hl.ViewData();
					System.out.println("HOTEL NAME" + HotelName);
					break;
				}
				case 3: {
					
					if(hl.updateData())
					 System.out.println("Updated Successfully:" +HotelName);		
					 break;
				}
				case 4: {
					if(hl.deleteData())
					System.out.println("Removed Successfully:" +HotelName);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}

	}

}
