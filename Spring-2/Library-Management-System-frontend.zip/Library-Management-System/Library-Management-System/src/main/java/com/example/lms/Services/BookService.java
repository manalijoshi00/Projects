package com.example.lms.Services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.Repository.BookRepository;
import com.example.lms.entity.Book;

@Service
public class BookService {
	
	@Autowired
	private BookRepository brepo;
	
	public List<Book> findAll(){
		
	   return brepo.findAll();
	}

	public Book save(Book book) {
		return brepo.save(book);
	}
	
	public Optional<Book> fetchBookById(long id ) {
		
		return brepo.findById(id);
	}
	
	
	
	public String deleteBookById(long id ) {
		
		String result;
		try {
			brepo.deleteById(id);
			result = "book successfully deleted";
			
		} catch(Exception e) {
			result = "book with id is not deleted";
		}
		return result;
		
	}

}
