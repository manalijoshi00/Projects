package com.entity;

import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name="Reservation")
public class Reservation {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="RNumber")
	private int RNumber;
	@Column(name="CheckInDate")
	private java.sql.Date CheckInDate;
	@Column(name="CheckOutDate")
	private java.sql.Date CheckOutDate;
	@Column(name="Status")
	private String Status;
	@Column(name="NumberOfGuest")
	private int NumberOfGuest;
	@Column(name="ReservationDate")
	private java.sql.Date ReservationDate;
	
	@OneToMany(mappedBy ="reservation", cascade = CascadeType.ALL)
    private Set<Customer> customer = new HashSet<Customer>(0);

	public int getRNumber() {
		return RNumber;
	}
	public void setRNumber(int rNumber) {
		RNumber = rNumber;
	}
	public java.sql.Date getCheckInDate() {
		return CheckInDate;
	}
	public void setCheckInDate(java.sql.Date checkInDate) {
		CheckInDate = checkInDate;
	}
	public java.sql.Date getCheckOutDate() {
		return CheckOutDate;
	}
	public void setCheckOutDate(java.sql.Date checkOutDate) {
		CheckOutDate = checkOutDate;
	}
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getNumberOfGuest() {
		return NumberOfGuest;
	}
	public void setNumberOfGuest(int numberOfGuest) {
		NumberOfGuest = numberOfGuest;
	}
	public java.sql.Date getReservationDate() {
		return ReservationDate;
	}
	public void setReservationDate(java.sql.Date reservationDate) {
		ReservationDate = reservationDate;
	}
	public Set<Customer> getCustomer() {
		return customer;
	}
	public void setCustomer(Set<Customer> customer) {
		this.customer = customer;
	}


}
