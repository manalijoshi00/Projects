import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ServiceService } from '../service.service';
import { Book } from '../book';

@Component({
  selector: 'app-view-book',
  templateUrl: './view-book.component.html',
  styleUrls: ['./view-book.component.css']
})
export class ViewBookComponent implements OnInit {

  book = new Book();

  constructor(private _route: Router,private _service: ServiceService,private _activeRoute: ActivatedRoute) { }

  ngOnInit(): void {
    let id = parseInt(this._activeRoute.snapshot.paramMap.get('id') || '{}');
    this._service.fetchBookByIdFromRemote(id).subscribe(
      data =>{
        console.log("data recieved");
        this.book = data;
      },
      error =>console.log("exception occured")
    )
  }

  gotolist() {
    console.log('go back');
    this._route.navigate(['booklist']);
  }
    
  }


