package com.Service;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		
		String ServiceName ="";
		ServiceLogic sl=new ServiceLogic();
		Services service=new Services();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(sl.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					ServiceName=sl.ViewData();
					System.out.println("SERVICE NAME" +ServiceName);
					break;
				}
				case 3: {
					if(sl.updateData())
				     System.out.println("Updated Successfully.." +ServiceName);
					 break;
				}
				case 4: {
					if(sl.deleteData())
					System.out.println("Removed Successfully.." +ServiceName);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}


	}

}
