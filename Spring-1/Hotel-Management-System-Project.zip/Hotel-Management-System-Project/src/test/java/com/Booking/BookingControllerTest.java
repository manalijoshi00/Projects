package com.Booking;

import static org.junit.Assert.*;

import org.junit.Test;

public class BookingControllerTest {

	@Test
	public void testAddData() {
		BookingController bc=new BookingController();
		assertTrue(bc.addData());
	}

	@Test
	public void testViewData() {
		BookingController bc=new BookingController();
		assertTrue(bc.addData());
	}

	@Test
	public void testUpdateData() {
		BookingController bc=new BookingController();
		assertTrue(bc.updateData());
		
	}

	@Test
	public void testDeleteData() {
		BookingController bc=new BookingController();
		assertTrue(bc.deleteData());
	}

}
