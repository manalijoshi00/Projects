package com.Hotel;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class HotelLogic {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String HotelName = JOptionPane.showInputDialog(jp, "Enter your HotelName:");
		     String City = JOptionPane.showInputDialog(jp, "Enter your City:");
		     String State = JOptionPane.showInputDialog(jp, "Enter your State:");
		     String HotelType = JOptionPane.showInputDialog(jp, "Enter your HotelType:");
		     String HotelRent = JOptionPane.showInputDialog(jp, "Enter your HotelRent:");
		     String Zipcode = JOptionPane.showInputDialog(jp, "Enter your Zipcode:");
		     
		     
		     Hotels h = new Hotels();
		     h.setHotelName(HotelName);
		     h.setCity(City);
		     h.setState(State);
		     h.setHotelType(HotelType);
		     h.setHotelRent(HotelRent);
		     h.setZipcode(Zipcode);
		     em.persist(h);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotels h2 = em.find(Hotels.class,1);
		
		String HotelName= h2.getHotelName();
		et.commit();
		return HotelName;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotels h2 = em.find(Hotels.class, 1);
		h2.setCity("City"); 
		System.out.println("Updated.."+h2.getCity());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Hotels h2 = em.find(Hotels.class, 5);
		if(h2!=null)
			em.remove(h2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }



}
