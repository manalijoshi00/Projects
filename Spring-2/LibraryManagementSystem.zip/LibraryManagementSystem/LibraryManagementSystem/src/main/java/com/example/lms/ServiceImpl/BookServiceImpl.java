package com.example.lms.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lms.entity.Book;
import com.example.lms.repository.BookRepository;
import com.example.lms.service.BookService;

@Service
public class BookServiceImpl implements BookService {
	
	@Autowired
	BookRepository brepo;

	@Override
	public Book saveB(Book book){
		return brepo.save(book);
	}

	@Override
	public Book getBid(long id) {
		return brepo.findById(id).get();
	}

	@Override
	public List<Book> getB() {
		return brepo.findAll();
	}

	@Override
	public Book updateBid(Book book, long id) {
		
		Book bs = brepo.findById(id).get();
		
		bs.setGenre(book.getGenre());
		
		brepo.save(bs);
		
		return bs;
	}

	@Override
	public void deleteBid(long id) {
		
		brepo.findById(id).get();
		brepo.deleteById(id);
		
	}
	
	@Override
	public List<Book> getBName(String name){
		
		return brepo.getBName(name);
	}

}
