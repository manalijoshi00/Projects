package com.customer;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import com.Booking.Booking;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class CustomerController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String CName = JOptionPane.showInputDialog(jp, "Enter your CName:");
		     String CAge = JOptionPane.showInputDialog(jp, "Enter your CAge:");
		     String CGender = JOptionPane.showInputDialog(jp, "Enter your CGender:");
		     String CMobile = JOptionPane.showInputDialog(jp, "Enter your CMobile:");
		     String CEmail = JOptionPane.showInputDialog(jp, "Enter your CEmail:");
		     String CAddress = JOptionPane.showInputDialog(jp, "Enter your CAddress:");
		     
		     Customer c = new Customer();
		     c.setCName(CName);
		     c.setCAge(CAge);
		     c.setGender(CGender);
		     c.setGender(CGender);
		     c.setCMobile(0);
		     c.setCEmail(CEmail);
		     c.setCAddress(CAddress);
		     em.persist(c);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Customer c2 = em.find(Customer.class, 1);
		
		String CName= c2.getCName();
		et.commit();
		return CName;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Customer c2 = em.find(Customer.class, 1);
		
		c2.setCAge("CAge");// UPDATE QUERY
		System.out.println("Updated.." +c2.getCAge());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Customer c2 = em.find(Customer.class, 4);
		if(c2!=null)
			em.remove(c2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }

}
