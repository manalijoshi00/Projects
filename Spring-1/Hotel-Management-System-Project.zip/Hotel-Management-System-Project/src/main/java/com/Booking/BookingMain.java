package com.Booking;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class BookingMain {

	public static void main(String[] args) {
		
		String BType="";
		BookingController bc=new BookingController();
		Booking booking=new Booking();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(bc.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					BType=bc.ViewData();
					System.out.println("BOOKING TYPE" + BType);
					break;
				}
				case 3: {
					
					if(bc.updateData())
					 System.out.println("Updated Successfully:" +BType);		
					 break;
				}
				case 4: {
					if(bc.deleteData())
					System.out.println("Removed Successfully:" +BType);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}
			

	}

}
