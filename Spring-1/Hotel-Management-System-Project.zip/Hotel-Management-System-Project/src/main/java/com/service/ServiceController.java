package com.service;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class ServiceController {
	
	public boolean addData() 
	{
		EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();

		et.begin();
		     JFrame jp = new JFrame();
		     String serviceId = JOptionPane.showInputDialog(jp, "Enter your serviceId:");
		     String serviceName = JOptionPane.showInputDialog(jp, "Enter your serviceName:");
		     String serviceType = JOptionPane.showInputDialog(jp, "Enter your serviceType:");
		     
		     Service s = new Service();
		     s.setServiceId(serviceId);
		     s.setServiceName(serviceName);
		     s.setServiceType(serviceType);
		     em.persist(s);// Insert Query
		     et.commit();
		     return true;
		     
	}
    public String ViewData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		 Service s2 = em.find(Service.class, 1);
		
		String serviceName= s2.getServiceName();
		et.commit();
		return serviceName;
    }
    public boolean updateData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Service s2 = em.find(Service.class, 1);
		s2.setServiceType("serviceType"); 
		System.out.println("Updated.."+s2.getServiceType());
		et.commit();
		return true;
		
    }
    public boolean deleteData() 
    {
    	EntityManagerFactory emf = null;
		EntityManager em = null;
		EntityTransaction et = null;
		JFrame jp = new JFrame();
		emf = Persistence.createEntityManagerFactory("HotelManagementUnit");
		em = emf.createEntityManager();
		et = em.getTransaction();
		et.begin();
		Service s2= em.find(Service.class, 4);
		if(s2!=null)
			em.remove(s2);
		else
			System.out.println("removed already");
		
		et.commit();
		return true;
    }



}
