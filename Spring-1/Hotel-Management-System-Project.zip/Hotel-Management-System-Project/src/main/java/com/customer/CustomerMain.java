package com.customer;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class CustomerMain {

	private static final String CAge = null;

	public static void main(String[] args) {
		
		String CName="";
		CustomerController cc=new CustomerController();
		Customer customer=new Customer();
			JFrame jp = new JFrame();
			System.out.println("1.INSERT Data");
			System.out.println("2.RETRIVE Data");
			System.out.println("3.UPDATE Data");
			System.out.println("4.DELETE Data");
			System.out.println("5.Quit");
			int option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
			while (option != 5) {
				option = Integer.parseInt(JOptionPane.showInputDialog(jp, "Enter your Choice:"));
				switch (option) {
				case 1: {
					if(cc.addData())
					JOptionPane.showMessageDialog(jp, "Succeussfully Inserted..", "Alert",
							JOptionPane.QUESTION_MESSAGE);
					break;
				}
				case 2: {
					CName=cc.ViewData();
					System.out.println("CUSTOMER NAME" + CName);
					break;
				}
				case 3: {
					if(cc.updateData())
						System.out.println("Congratulations" +CName+ "Updated Successfully:"+CAge);
				    break;
				}
				case 4: {
					if(cc.deleteData())
					System.out.println("Removed Successfully:" +CName);
					break;
				}
				case 5: {
					jp.setVisible(false);
					jp.dispose();

				}
				}
			}
			

	}

}
